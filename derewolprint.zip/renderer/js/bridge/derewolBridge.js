import jobStore from '../state/jobStore.js';

// ── Notification sonore ───────────────────────────────────────
function playNotification() {
  if (window.__derewolSoundEnabled === false) return;
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    [0, 0.18].forEach(delay => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.frequency.value = 880;
      osc.type = 'sine';
      gain.gain.setValueAtTime(0.3, ctx.currentTime + delay);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + delay + 0.12);
      osc.start(ctx.currentTime + delay);
      osc.stop(ctx.currentTime + delay + 0.12);
    });
  } catch (e) {}
}

function isDirectBluetoothGroup(job) {
  return (
    job &&
    job.isBluetooth === true &&
    Array.isArray(job.items) &&
    job.items.length > 0 &&
    !job.file_groups
  );
}

const sig = arr =>
  arr
    .map(g => `${g.id}:${g.items.map(i => `${i.jobId}:${i.fileId}`).join(',')}`)
    .sort()
    .join('|');

export function initBridge() {
  if (!window.derewol?.onJobReceived) return;

  window.derewol.onJobReceived(jobs => {
    const currentJobs = jobStore.getJobs();

    // ── Jobs Bluetooth (émission directe depuis le main) ─────
    if (jobs?.length && isDirectBluetoothGroup(jobs[0])) {
      const incoming = jobs.filter(isDirectBluetoothGroup);
      const incomingIds = new Set(incoming.map(g => g.id));
      const rest = currentJobs.filter(g => !incomingIds.has(g.id));
      const merged = [...rest, ...incoming];
      if (sig(currentJobs) !== sig(merged)) {
        const hasNew = incoming.some(g => !currentJobs.find(c => c.id === g.id));
        if (hasNew) playNotification();
        console.log('[BRIDGE] Jobs BT → merge UI');
        jobStore.setJobs(merged);
      }
      return;
    }

    // ── Jobs PWA (polling Supabase), conserver les groupes BT ─
    const map = {};

    (jobs || []).forEach(job => {
      const clientId = job.file_groups?.owner_id || 'Inconnu';
      const jobId = job.id;
      const fileGroupId = job.file_groups?.id;

      if (!map[clientId]) {
        map[clientId] = {
          id: `grp-${clientId}`,
          clientId,
          time: new Date(job.created_at).toLocaleTimeString(),
          items: [],
        };
      }

      const files = job.file_groups?.files || [];
      const linkedFile =
        files.find(f => f.id === job.file_id) || files[0] || null;

      if (!linkedFile) return;

      const exists = map[clientId].items.find(x => x.jobId === jobId);
      if (!exists) {
        map[clientId].items.push({
          jobId,
          fileGroupId,
          fileId: linkedFile.id,
          fileName: linkedFile.file_name,
        });
      }
    });

    const formatted = Object.values(map);
    const btGroups = currentJobs.filter(g => g.isBluetooth);
    const merged = [...formatted, ...btGroups];

    if (sig(currentJobs) !== sig(merged)) {
      console.log('[BRIDGE] Changement → update UI');
      const hasNew = merged.some(g => !currentJobs.find(c => c.id === g.id));
      if (hasNew) playNotification();
      jobStore.setJobs(merged);
    }
  });
}
