const supabase = require("./supabase");
const { loadConfig, saveConfig } = require("./printerConfig");

const PLANS = {
  trial: { days: 15, amount: 0, label: "15 jours gratuits" },
  "1month": { days: 30, amount: 4000, label: "1 mois — 4 000 FCFA" },
  "2months": { days: 61, amount: 6500, label: "2 mois — 6 500 FCFA (-19%)" },
  "3months": { days: 92, amount: 9000, label: "3 mois — 9 000 FCFA (-25%)" },
};

const GRACE_DAYS = 3;

async function ensureTrialOrSubscription(printerId) {
  try {
    const { data } = await supabase
      .from("subscriptions")
      .select("id")
      .eq("printer_id", printerId)
      .limit(1)
      .single();

    if (!data) {
      await supabase.rpc("create_trial_subscription", {
        p_printer_id: printerId,
      });
      console.log("[SUB] Période d'essai créée — 15 jours gratuits");
    }
  } catch (e) {
    console.warn("[SUB] ensureTrial:", e.message);
  }
}

async function checkSubscription(printerId) {
  try {
    await ensureTrialOrSubscription(printerId);
  } catch (_) {}

  // Cache local via printerConfig
  const cfg = loadConfig();
  if (cfg?.subscription?.expiresAt) {
    const exp = new Date(cfg.subscription.expiresAt);
    const now = new Date();
    const grace = new Date(exp.getTime() + GRACE_DAYS * 86400000);

    if (now < exp) {
      return {
        valid: true,
        expired: false,
        inGrace: false,
        daysLeft: Math.ceil((exp - now) / 86400000),
        expiresAt: cfg.subscription.expiresAt,
        plan: cfg.subscription.plan,
        isTrial: cfg.subscription.plan === "trial",
      };
    }
    if (now < grace) {
      return {
        valid: false,
        expired: true,
        inGrace: true,
        daysLeft: 0,
        graceLeft: Math.ceil((grace - now) / 86400000),
        expiresAt: cfg.subscription.expiresAt,
      };
    }
  }

  // DB
  try {
    const { data } = await supabase
      .from("subscriptions")
      .select("expires_at, status, plan, activated_at")
      .eq("printer_id", printerId)
      .eq("status", "active")
      .order("expires_at", { ascending: false })
      .limit(1)
      .single();

    if (!data)
      return { valid: false, expired: true, inGrace: false, daysLeft: 0 };

    const exp = new Date(data.expires_at);
    const now = new Date();
    const grace = new Date(exp.getTime() + GRACE_DAYS * 86400000);

    const result = {
      valid: now < exp,
      expired: now >= exp,
      inGrace: now >= exp && now < grace,
      daysLeft: Math.max(0, Math.ceil((exp - now) / 86400000)),
      graceLeft: now >= exp ? Math.ceil((grace - now) / 86400000) : 0,
      expiresAt: data.expires_at,
      plan: data.plan,
      isTrial: data.plan === "trial",
    };

    // Mettre à jour le cache dans printerConfig
    const currentCfg = loadConfig() || {};
    saveConfig({ ...currentCfg, subscription: result });
    return result;
  } catch (e) {
    console.warn("[SUB] checkSubscription DB error:", e.message);
    return { valid: true, expired: false, inGrace: false, daysLeft: 999 };
  }
}

async function activateCode(printerId, code) {
  const normalized = (code || "").toUpperCase().trim();

  const { data, error } = await supabase
    .from("subscriptions")
    .select("*")
    .eq("activation_code", normalized)
    .eq("status", "pending")
    .single();

  if (error || !data)
    return { success: false, error: "Code invalide ou déjà utilisé" };

  if (data.printer_id && data.printer_id !== printerId) {
    return { success: false, error: "Ce code n'est pas pour votre boutique" };
  }

  const plan = PLANS[data.plan] || PLANS["1month"];

  // Prolonge depuis expiration actuelle si abonnement actif
  let base = new Date();
  try {
    const { data: current } = await supabase
      .from("subscriptions")
      .select("expires_at")
      .eq("printer_id", printerId)
      .eq("status", "active")
      .order("expires_at", { ascending: false })
      .limit(1)
      .single();

    if (current?.expires_at && new Date(current.expires_at) > new Date()) {
      base = new Date(current.expires_at);
    }
  } catch (_) {}

  const expiresAt = new Date(base.getTime() + plan.days * 86400000);

  const { error: upErr } = await supabase
    .from("subscriptions")
    .update({
      printer_id: printerId,
      status: "active",
      activated_at: new Date().toISOString(),
      expires_at: expiresAt.toISOString(),
    })
    .eq("id", data.id);

  if (upErr) return { success: false, error: "Erreur activation" };

  const currentCfg = loadConfig() || {};
  saveConfig({
    ...currentCfg,
    subscription: {
      expiresAt: expiresAt.toISOString(),
      daysLeft: plan.days,
      plan: data.plan,
    },
  });

  return {
    success: true,
    expiresAt: expiresAt.toISOString(),
    daysLeft: plan.days,
    plan: data.plan,
    message: `Abonnement activé — ${plan.label} — expire le ${expiresAt.toLocaleDateString("fr-FR")}`,
  };
}

module.exports = {
  checkSubscription,
  activateCode,
  ensureTrialOrSubscription,
  PLANS,
};
